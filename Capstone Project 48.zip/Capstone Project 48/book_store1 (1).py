#!/usr/bin/env python
# coding: utf-8

# In[1]:


#pip install mysql-connector-python


# In[2]:


# importing the library to connect the mysql into python
import mysql.connector


# In[3]:


# connecting the database student by connecting mysql with given  username and password 
mydb= mysql.connector.connect(host='localhost',password=('ganesh@72'),user='root',database='student')


# In[4]:


#once database is connected we have to open the database and put the cursor at the first record
cur = mydb.cursor()


# ### create a Table

# In[6]:


# creating the table b7 with the given column names in the question and assign the query to the variable b

b="create table b7(id int,title varchar(40),author varchar(40),qty int)"


# In[7]:


# After creating the table we have to save the changes using commit command
mydb.commit()


# In[8]:


#executes the query and table will be created
cur.execute(b)


# In[13]:


# inserting the values into a table by giving list of the values using the parameterized values
b="insert into b7(id, title,author,qty) values (%s,%s,%s,%s)"


# In[14]:


book=[(3001,'A tale of Two cities','Charles Dickens',30),
      (3002,'Harry Potter and the Philosophers Stone','jk powling',40),
      (3003,'The Lion the Witch and the Wardrobe','CS Lewis', 25),
      ( 3004,'The Land of the Rings','JRR Tolkein',37),
      ( 3005, 'Alice Wonderland','Lewin Carrol',12)]


# In[15]:


# the following query excutemany will be inserting the values in one go 
cur.executemany(b,book)


# In[16]:


#save the changes
mydb.commit()


# In[17]:


# assigning the query to display all records from created table
s='select * from b7'


# In[18]:


cur.execute(s)


# In[19]:


# Fetching all the records
result=cur.fetchall()


# ### Display all records once table is created

# In[20]:


for rec in result:
    print(rec)


# ### Function to insert a record

# In[69]:


def ins():
    # Read the column names 
    Bid=int(input("Enter the Book Id"))
    Bname=input("Enter the Book name")
    Bauthor=input("Enter the Book Author")
    Bqty=int(input("Enter the BOOk qty"))
    
    #paramaterised insert statement
    query="insert into b7 values ({},'{}','{}',{})".format(Bid,Bname,Bauthor,Bqty)
    cur.execute(query)
    # After executing the query the rows will not be affected in the table.. we can see the inserted records once we save
    #them by using commit command
    mydb.commit()
    print("Row inserted successfully")
    # To view the inserted records using userdefined function display() 
    display()
    
    


# ### Function to search a record through author name

# In[68]:


#user defined function diplay to  search  the record based on the given author 
def disp():
    #read the name of the author
    a=input("Enter author name")
    # Query to search the book information with the parameterised variable a
    query="select * from b7 where author='{}'".format(a)
    cur.execute(query)
    # fetch all the records which are matched with the given condition
    result=cur.fetchall()
    #using for loop to display all the matched records
    for i in result:
        print(i)

    


# ### Function to update a record

# In[67]:


#this is user defined function to update the record using parameterised column name author
def upd():
    o=input("Enter   author name: ")
    # to update the qty of the given authors of the given author 
    # as the qty is integer we are trying to convert the value into int as by default the input statement access the string 
    qty=int(input("Enter quantity of the authorname to be updated"))
    # query to update the record by using parameterized value
    query="update b7 set qty={} where author='{}'".format(qty,o)
    cur.execute(query)
    #save the changes
    mydb.commit()
    print("Row updated successfully")
    
     # displays the updated records
    query="select * from b7 where author='{}'".format(o)
    cur.execute(query)
    result=cur.fetchall()
    for i in result:
        print(i)


    


# ### function to delete a record

# In[75]:


#defining the function to delete the record

def dele():
    a=input("Enter author name")
    query="delete from b7 where author='{}'".format(a)
    cur.execute(query)
    mydb.commit()
    print("record  deleted sucessfully")
    # TO check whether the record is deleted successfully or not and display all the records
    display()


# ### function to display all the records

# In[76]:


def display():
    query="select * from b7 "
    cur.execute(query)
    result=cur.fetchall()
    for i in result:
        print(i)


# ### Mainfunction to display menu and select the choice

# In[77]:


# defining main function  to read the choice by the user

def main():
    print('Available Options: I=Insert, S=Search, U=Update, D=Delete ')
    
    choice = input('Choose your option = ')

    if (choice == 'i'or choice == 'I'):
         ins()
    elif (choice == 's' or choice == 'S'):
          disp()
    elif (choice == 'U'  or choice == 'u'):
        upd()
    elif (choice == 'D' or choice == 'd'):
        dele()
    else:
        print('Wrong choice, You are going exist.')
        
# calling the main function 
main()


# In[ ]:




